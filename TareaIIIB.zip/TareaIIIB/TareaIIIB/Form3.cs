﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TareaIIIB
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public string idnomina;
        private void Form3_Load(object sender, EventArgs e)
        {
            NominaReporte objreporte = new NominaReporte();
            //objreporte.SetParameterValue(@idnomina,idnomina);
            objreporte.Load(idnomina);/*me funciono*/
           

            crystalReportViewer1.ReportSource = objreporte;
        }
    }
}
